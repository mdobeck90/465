#! /usr/bin/env ruby

term = ARGV[0]
term = term.downcase
puts "Searching for \"#{term}\""
