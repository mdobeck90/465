#!/usr/bin/env ruby

puts "Hello! What's your name?"
name = gets.chomp
puts "Ok, #{name}"
